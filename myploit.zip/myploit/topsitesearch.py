from bs4 import BeautifulSoup
import requests
import os
from concurrent.futures import ThreadPoolExecutor

linux = "clear"
windows = "cls"
os.system([linux, windows][os.name == "nt"])

banner = '''
// t.me/firmansec
'''.format('\033[33m')
print('\033[32m'+banner)
green = '\033[32m'
print('\033[1;37m')
def Main():
	global green
	domain_ip = input('[#] Pilih domain di atas salah satu, ketik huruf kecil depannya . (.net) > ')
	go_page = int(input('[#] Mulai Dari Page > '))
	page=(go_page-1)
	end_page = int(input('[#] End Page > '))
	epage=(end_page+1)
	save_ip = input('[#] Result Name > ')
	while True:
		page += 1
		url = 'https://www.topsitessearch.com/domains/'+domain_ip+'/'+str(page)
		Agents = {'User-Agent':'Mozilla/5.0 (Linux; Android 9; SM-A530F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.192 Mobile Safari/537.36 OPR/74.0.3922.70977'}
		r = requests.get(url,headers=Agents).text
		bs = BeautifulSoup(r,'html.parser')
		try:
			find = bs.find('tbody').find_all('tr')
		except:
			pass
		stop = 'https://www.topsitessearch.com/domains/.com/'+str(epage)
		if stop in url:
			break
		else:
			for a in find:
				c = a.find('td').text
				rmv = c.replace('1','').replace('2','').replace('3','').replace('4','').replace('5','').replace('6','').replace('7','').replace('8','').replace('9','').replace('10','').replace(':','').replace('0','')
				spc_rmv = rmv.strip()
				print(f'{green}{page} > {spc_rmv}')
				open(save_ip,'a').write(spc_rmv+'\n')
				print('\033[1;37m')
Main()